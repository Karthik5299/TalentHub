const Leave = require('../models/Leave');
const ApiResponse = require('../utils/apiResponse');

// ─────────────────────────────────────────────
// @desc   Apply for leave
// @route  POST /api/leaves
// @access Private
// Body:   { leaveType, startDate, endDate, reason, employeeId? (admin only) }
// ─────────────────────────────────────────────
exports.applyLeave = async (req, res, next) => {
  try {
    const { leaveType, startDate, endDate, reason } = req.body;

    // Determine which employee this is for
    let employeeId;
    if (req.user.role === 'admin') {
      if (!req.body.employeeId) return ApiResponse.error(res, 'employeeId is required for admin', 400);
      employeeId = req.body.employeeId;
    } else {
      // Employee applies for themselves — must have a linked employee record
      if (!req.user.employeeId) {
        return ApiResponse.error(res, 'Your user account is not linked to an employee record. Contact admin.', 400);
      }
      employeeId = req.user.employeeId;
    }

    if (!leaveType || !startDate || !endDate || !reason) {
      return ApiResponse.error(res, 'leaveType, startDate, endDate and reason are required', 400);
    }

    const validTypes = ['annual', 'sick', 'maternity', 'paternity', 'unpaid', 'other'];
    if (!validTypes.includes(leaveType)) {
      return ApiResponse.error(res, `leaveType must be one of: ${validTypes.join(', ')}`, 400);
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return ApiResponse.error(res, 'Invalid date format. Use YYYY-MM-DD', 400);
    }
    if (end < start) {
      return ApiResponse.error(res, 'endDate cannot be before startDate', 400);
    }

    // Check for overlapping non-declined leaves
    const overlap = await Leave.findOne({
      employee: employeeId,
      status: { $ne: 'declined' },
      startDate: { $lte: end },
      endDate: { $gte: start },
    });
    if (overlap) {
      return ApiResponse.error(res, 'A leave application already exists overlapping these dates', 409);
    }

    const leave = await Leave.create({ employee: employeeId, leaveType, startDate: start, endDate: end, reason });
    await leave.populate('employee', 'firstName lastName employeeCode');
    return ApiResponse.success(res, { leave }, 'Leave application submitted', 201);
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────
// @desc   Get leaves — admins see all, employees see own
// @route  GET /api/leaves
// @access Private
// Query:  status, employeeId (admin), page, limit
// ─────────────────────────────────────────────
exports.getLeaves = async (req, res, next) => {
  try {
    const { status, employeeId, page = 1, limit = 20 } = req.query;
    const query = {};

    if (req.user.role === 'admin') {
      if (employeeId) query.employee = employeeId;
    } else {
      // Employees can only see their own
      if (!req.user.employeeId) return ApiResponse.paginated(res, [], 0, page, limit, 'No linked employee record');
      query.employee = req.user.employeeId;
    }

    if (status) query.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [leaves, total] = await Promise.all([
      Leave.find(query)
        .populate('employee', 'firstName lastName employeeCode department')
        .populate('reviewedBy', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      Leave.countDocuments(query),
    ]);

    return ApiResponse.paginated(res, leaves, total, page, limit, 'Leaves fetched');
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────
// @desc   Get single leave
// @route  GET /api/leaves/:id
// @access Private
// ─────────────────────────────────────────────
exports.getLeave = async (req, res, next) => {
  try {
    const leave = await Leave.findById(req.params.id)
      .populate('employee', 'firstName lastName employeeCode')
      .populate('reviewedBy', 'name');

    if (!leave) return ApiResponse.error(res, 'Leave not found', 404);

    // Employees can only view their own
    if (req.user.role !== 'admin' && String(leave.employee._id) !== String(req.user.employeeId)) {
      return ApiResponse.error(res, 'Not authorised to view this leave', 403);
    }

    return ApiResponse.success(res, { leave }, 'Leave fetched');
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────
// @desc   Review (approve/decline) a leave — admin only
// @route  PUT /api/leaves/:id/review
// @access Private — Admin
// Body:   { status: 'approved'|'declined', adminNote? }
// ─────────────────────────────────────────────
exports.reviewLeave = async (req, res, next) => {
  try {
    const { status, adminNote } = req.body;
    if (!['approved', 'declined'].includes(status)) {
      return ApiResponse.error(res, "status must be 'approved' or 'declined'", 400);
    }

    const leave = await Leave.findById(req.params.id);
    if (!leave) return ApiResponse.error(res, 'Leave not found', 404);
    if (leave.status !== 'pending') {
      return ApiResponse.error(res, `Leave already ${leave.status}. Only pending leaves can be reviewed.`, 400);
    }

    leave.status = status;
    if (adminNote) leave.adminNote = adminNote;
    leave.reviewedBy = req.user.id;
    leave.reviewedAt = new Date();
    await leave.save();
    await leave.populate('employee', 'firstName lastName employeeCode');

    return ApiResponse.success(res, { leave }, `Leave ${status} successfully`);
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────
// @desc   Cancel a pending leave (employee cancels own, admin cancels any)
// @route  DELETE /api/leaves/:id
// @access Private
// ─────────────────────────────────────────────
exports.cancelLeave = async (req, res, next) => {
  try {
    const leave = await Leave.findById(req.params.id);
    if (!leave) return ApiResponse.error(res, 'Leave not found', 404);

    if (req.user.role !== 'admin' && String(leave.employee) !== String(req.user.employeeId)) {
      return ApiResponse.error(res, 'Not authorised to cancel this leave', 403);
    }
    if (leave.status !== 'pending') {
      return ApiResponse.error(res, 'Only pending leaves can be cancelled', 400);
    }

    await leave.deleteOne();
    return ApiResponse.success(res, {}, 'Leave cancelled');
  } catch (error) { next(error); }
};

// ─────────────────────────────────────────────
// @desc   Leave statistics
// @route  GET /api/leaves/stats
// @access Private — Admin
// ─────────────────────────────────────────────
exports.getLeaveStats = async (req, res, next) => {
  try {
    const raw = await Leave.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);
    const stats = { pending: 0, approved: 0, declined: 0 };
    raw.forEach((s) => { stats[s._id] = s.count; });
    const total = stats.pending + stats.approved + stats.declined;
    return ApiResponse.success(res, { stats, total }, 'Leave stats fetched');
  } catch (error) { next(error); }
};
