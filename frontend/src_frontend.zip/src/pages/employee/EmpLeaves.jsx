import React, { useCallback, useEffect, useState } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';

const Card = ({ children, className = '' }) => (
  <div className={`rounded-2xl border border-slate-200 bg-white shadow-sm ${className}`}>
    {children}
  </div>
);

const statusClass = {
  approved: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
  pending: 'bg-amber-50 text-amber-700 border border-amber-200',
  declined: 'bg-rose-50 text-rose-700 border border-rose-200',
};

const StatusPill = ({ status }) => (
  <span
    className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold capitalize tracking-wide ${
      statusClass[String(status).toLowerCase()] ||
      'bg-slate-100 text-slate-700 border border-slate-200'
    }`}
  >
    {status || 'unknown'}
  </span>
);

const formatDate = (date, options = {}) => {
  if (!date) return '—';
  return new Date(date).toLocaleDateString('en-IN', options);
};

const getDurationDays = (start, end) => {
  if (!start || !end) return 0;
  const s = new Date(start);
  const e = new Date(end);
  return Math.ceil((e - s) / 86400000) + 1;
};

export default function EmpLeaves() {
  const [leaves, setLeaves] = useState([]);
  const [busy, setBusy] = useState(true);
  const [modal, setModal] = useState(false);
  const [saving, setSaving] = useState(false);

  const [form, setForm] = useState({
    leaveType: 'annual',
    startDate: '',
    endDate: '',
    reason: '',
  });

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const r = await api.get('/leaves');
      setLeaves(r?.data?.data || []);
    } catch (e) {
      toast.error('Failed to load leave records');
    } finally {
      setBusy(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const apply = async () => {
    if (!form.startDate || !form.endDate || !form.reason.trim()) {
      toast.error('Fill all leave details');
      return;
    }

    setSaving(true);
    try {
      await api.post('/leaves', form);
      toast.success('Leave request submitted');
      setModal(false);
      setForm({
        leaveType: 'annual',
        startDate: '',
        endDate: '',
        reason: '',
      });
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Failed to apply for leave');
    } finally {
      setSaving(false);
    }
  };

  const cancelLeave = async (id) => {
    if (!window.confirm('Cancel this leave request?')) return;
    try {
      await api.delete(`/leaves/${id}`);
      toast.success('Leave cancelled');
      load();
    } catch (e) {
      toast.error(e?.response?.data?.message || 'Failed to cancel leave');
    }
  };

  const counts = {
    pending: leaves.filter((l) => l.status === 'pending').length,
    approved: leaves.filter((l) => l.status === 'approved').length,
    declined: leaves.filter((l) => l.status === 'declined').length,
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">My leaves</h1>
          <p className="mt-1 text-sm text-slate-500">
            Apply for time off and track approval progress.
          </p>
        </div>
        <button
          onClick={() => setModal(true)}
          className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800"
        >
          Apply leave
        </button>
      </div>

      {!busy && leaves.length ? (
        <div className="grid gap-4 md:grid-cols-3">
          {[
            ['Pending requests', counts.pending, 'Awaiting review'],
            ['Approved', counts.approved, 'Accepted leave requests'],
            ['Declined', counts.declined, 'Not approved'],
          ].map(([title, value, hint]) => (
            <Card key={title} className="p-5 transition duration-300 hover:-translate-y-1 hover:shadow-md">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">{title}</p>
              <p className="mt-2 text-2xl font-semibold tracking-tight text-slate-900">{value}</p>
              <p className="mt-2 text-sm text-slate-500">{hint}</p>
            </Card>
          ))}
        </div>
      ) : null}

      {busy ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-20 animate-pulse rounded-2xl bg-slate-100" />
          ))}
        </div>
      ) : !leaves.length ? (
        <Card>
          <div className="px-6 py-14 text-center">
            <div className="mb-4 text-4xl">🌴</div>
            <h3 className="text-lg font-semibold text-slate-900">No leave requests yet</h3>
            <p className="mt-2 text-sm text-slate-500">Create your first leave request to get started.</p>
            <button
              onClick={() => setModal(true)}
              className="mt-5 rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800"
            >
              Apply now
            </button>
          </div>
        </Card>
      ) : (
        <div className="space-y-4">
          {leaves.map((lv) => (
            <Card key={lv.id}>
              <div className="p-5">
                <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <h3 className="text-lg font-semibold text-slate-900">{lv.leaveType} leave</h3>
                      <StatusPill status={lv.status} />
                    </div>

                    <p className="mt-2 text-sm text-slate-500">
                      {formatDate(lv.startDate, { day: 'numeric', month: 'short' })} -{' '}
                      {formatDate(lv.endDate, { day: 'numeric', month: 'short', year: 'numeric' })} •{' '}
                      {lv.totalDays || getDurationDays(lv.startDate, lv.endDate)} day(s)
                    </p>

                    <p className="mt-3 text-sm leading-6 text-slate-600">{lv.reason || 'No reason provided.'}</p>

                    {lv.adminNote ? (
                      <div className="mt-3 rounded-xl border border-sky-200 bg-sky-50 px-4 py-3 text-sm text-sky-700">
                        Admin note: {lv.adminNote}
                      </div>
                    ) : null}
                  </div>

                  {lv.status === 'pending' && (
                    <button
                      onClick={() => cancelLeave(lv.id)}
                      className="rounded-xl bg-rose-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-rose-700"
                    >
                      Cancel request
                    </button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/45 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-3xl bg-white shadow-2xl animate-[fadeUp_.25s_ease]">
            <div className="flex items-start justify-between border-b border-slate-100 px-6 py-5">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">Apply for leave</h3>
                <p className="mt-1 text-sm text-slate-500">Enter leave details and submit your request.</p>
              </div>
              <button
                onClick={() => setModal(false)}
                className="rounded-xl p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700"
              >
                ✕
              </button>
            </div>

            <div className="px-6 py-5">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                    Leave type
                  </label>
                  <select
                    value={form.leaveType}
                    onChange={(e) => setForm((f) => ({ ...f, leaveType: e.target.value }))}
                    className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-slate-400"
                  >
                    {['annual', 'sick', 'maternity', 'paternity', 'unpaid', 'other'].map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4">
                  <p className="text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">Duration</p>
                  <p className="mt-2 text-2xl font-semibold text-slate-900">
                    {getDurationDays(form.startDate, form.endDate)} day(s)
                  </p>
                  <p className="mt-1 text-sm text-slate-500">Calculated from selected dates</p>
                </div>

                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                    Start date
                  </label>
                  <input
                    type="date"
                    value={form.startDate}
                    min={new Date().toISOString().slice(0, 10)}
                    onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))}
                    className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-slate-400"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                    End date
                  </label>
                  <input
                    type="date"
                    value={form.endDate}
                    min={form.startDate || new Date().toISOString().slice(0, 10)}
                    onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))}
                    className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-slate-400"
                  />
                </div>
              </div>

              <div className="mt-4">
                <label className="mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                  Reason
                </label>
                <textarea
                  rows={4}
                  placeholder="Briefly explain the reason for your leave request"
                  value={form.reason}
                  onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))}
                  className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-slate-400"
                />
              </div>

              <div className="mt-6 flex flex-wrap justify-end gap-3">
                <button
                  onClick={() => setModal(false)}
                  className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  onClick={apply}
                  disabled={saving}
                  className="rounded-xl bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 disabled:opacity-60"
                >
                  {saving ? 'Submitting...' : 'Submit request'}
                </button>
              </div>
            </div>
          </div>

          <style>{`
            @keyframes fadeUp {
              from { opacity: 0; transform: translateY(14px) scale(.98); }
              to { opacity: 1; transform: translateY(0) scale(1); }
            }
          `}</style>
        </div>
      )}
    </div>
  );
}