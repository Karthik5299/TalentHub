import React, { useState, useEffect, useCallback } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';

/* ── shared helpers ── */
const F = (setForm, key) => e => setForm(f => ({...f, [key]: e.target.value}));
const Spinner = () => <div className="aspinner" style={{display:'inline-block'}}/>;

/* ════════════════════════════════════════
   ADMIN ATTENDANCE
════════════════════════════════════════ */
export function AdminAttendance() {
  const [data,  setData]  = useState(null);
  const [emps,  setEmps]  = useState([]);
  const [empId, setEmpId] = useState('');
  const [busy,  setBusy]  = useState(true);
  const [clk,   setClk]   = useState(false);
  const [now,   setNow]   = useState(new Date());

  useEffect(()=>{const t=setInterval(()=>setNow(new Date()),1000);return()=>clearInterval(t);},[]);

  const load=useCallback(async()=>{
    setBusy(true);
    try{const r=await api.get('/attendance/today');setData(r.data.data||{});}
    catch{}finally{setBusy(false);}
  },[]);
  useEffect(()=>{load();api.get('/employees',{params:{limit:100}}).then(r=>setEmps(r.data.data||[])).catch(()=>{});},[load]);

  const clockIn =async()=>{if(!empId){toast.error('Select employee');return;}setClk(true);try{await api.post('/attendance/clock-in',{employeeId:empId});toast.success('Clocked in!');load();}catch{}finally{setClk(false);};};
  const clockOut=async(id)=>{setClk(true);try{await api.post('/attendance/clock-out',{employeeId:id||empId});toast.success('Clocked out!');load();}catch{}finally{setClk(false);};};
  const fmt=d=>d?new Date(d).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):'—';

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:22,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>Attendance</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Live tracking · {new Date().toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'short'})}</p></div>
        <div style={{fontFamily:'var(--a-mono)',fontSize:20,fontWeight:700,color:'var(--a-text)',letterSpacing:'-.02em'}}>{now.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}</div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(150px,1fr))',gap:12,marginBottom:18}}>
        {[['Total',data?.stats?.totalEmployees,'var(--a-text)'],['Present',data?.stats?.present,'#16a34a'],['Absent',data?.stats?.absent,'#dc2626'],['Rate',data?.stats?.attendanceRate!=null?`${data.stats.attendanceRate}%`:null,'#2563eb']].map(([l,v,c])=>(
          <div key={l} className="acard" style={{padding:16}}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--a-t3)',marginBottom:7}}>{l}</div>
            <div style={{fontSize:24,fontWeight:700,fontFamily:'var(--a-mono)',color:c}}>{v??'—'}</div>
          </div>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1.6fr',gap:14,marginBottom:14}}>
        <div className="acard" style={{padding:18}}>
          <div style={{fontSize:13,fontWeight:600,marginBottom:14}}>Quick Clock In/Out</div>
          <select className="ainput" style={{marginBottom:11}} value={empId} onChange={e=>setEmpId(e.target.value)}>
            <option value="">Select employee…</option>
            {emps.map(e=><option key={e._id} value={e._id}>{e.firstName} {e.lastName} ({e.employeeCode})</option>)}
          </select>
          <div style={{display:'flex',gap:8}}>
            <button className="abtn abtn-success" style={{flex:1,justifyContent:'center'}} onClick={clockIn} disabled={clk||!empId}>{clk?<Spinner/>:null} In</button>
            <button className="abtn abtn-danger"  style={{flex:1,justifyContent:'center'}} onClick={()=>clockOut()} disabled={clk||!empId}>{clk?<Spinner/>:null} Out</button>
          </div>
        </div>
        <div className="acard" style={{overflow:'hidden'}}>
          <div style={{padding:'13px 14px 9px',fontSize:13,fontWeight:600}}>Active Staff <span style={{fontSize:11,fontWeight:400,color:'var(--a-t3)',fontFamily:'var(--a-mono)'}}>{data?.activeStaff?.length||0} on duty</span></div>
          <div className="tscroll" style={{maxHeight:180,overflowY:'auto'}}>
            <table className="atable">
              <thead><tr><th>Name</th><th>In</th><th>Status</th><th>Action</th></tr></thead>
              <tbody>
                {busy?<tr><td colSpan={4}><div style={{padding:20,textAlign:'center',fontSize:11,color:'var(--a-t3)'}}>Loading…</div></td></tr>
                :!data?.activeStaff?.length?<tr><td colSpan={4}><div className="aempty" style={{padding:24}}>No active staff</div></td></tr>
                :data.activeStaff.map(r=>(
                  <tr key={r._id}>
                    <td style={{fontWeight:500,color:'var(--a-text)'}}>{r.employee?.firstName} {r.employee?.lastName}</td>
                    <td style={{fontFamily:'var(--a-mono)',color:'#16a34a',fontSize:12}}>{fmt(r.clockIn)}</td>
                    <td><span className={`abadge ${r.status==='late'?'ab-amber':'ab-green'}`}>{r.status}</span></td>
                    <td><button className="abtn abtn-outline abtn-sm" onClick={()=>clockOut(r.employee?._id)}>Out</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {!!data?.completed?.length&&(
        <div className="acard" style={{overflow:'hidden'}}>
          <div style={{padding:'13px 14px 9px',fontSize:13,fontWeight:600}}>Completed Shifts</div>
          <div className="tscroll">
            <table className="atable">
              <thead><tr><th>Employee</th><th>In</th><th>Out</th><th>Hours</th><th>Status</th></tr></thead>
              <tbody>{data.completed.map(r=>(
                <tr key={r._id}>
                  <td style={{fontWeight:500,color:'var(--a-text)'}}>{r.employee?.firstName} {r.employee?.lastName}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:12}}>{fmt(r.clockIn)}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:12}}>{fmt(r.clockOut)}</td>
                  <td style={{fontFamily:'var(--a-mono)',color:'#2563eb'}}>{r.workHours}h</td>
                  <td><span className={`abadge ${r.status==='late'?'ab-amber':'ab-green'}`}>{r.status}</span></td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

/* ════════════════════════════════════════
   ADMIN LEAVES
════════════════════════════════════════ */
export function AdminLeaves() {
  const [leaves, setLeaves] = useState([]);
  const [emps,   setEmps]   = useState([]);
  const [stats,  setStats]  = useState({});
  const [filt,   setFilt]   = useState('');
  const [busy,   setBusy]   = useState(true);
  const [applyM, setApplyM] = useState(false);
  const [reviewL,setReviewL]= useState(null);
  const [saving, setSaving] = useState(false);
  const [form,   setForm]   = useState({employeeId:'',leaveType:'annual',startDate:'',endDate:'',reason:''});
  const [rev,    setRev]    = useState({status:'approved',adminNote:''});

  const load=useCallback(async()=>{
    setBusy(true);
    try{
      const p={}; if(filt)p.status=filt;
      const[l,s]=await Promise.all([api.get('/leaves',{params:p}),api.get('/leaves/stats')]);
      setLeaves(l.data.data || []);setStats(s.data.data.stats || {});
    }catch{}finally{setBusy(false);}
  },[filt]);
  useEffect(()=>{load();api.get('/employees',{params:{limit:100}}).then(r=>setEmps(r.data.data||[])).catch(()=>{});},[load]);

  const apply=async()=>{
    if(!form.employeeId||!form.startDate||!form.endDate||!form.reason){toast.error('Fill all fields');return;}
    setSaving(true);try{await api.post('/leaves',form);toast.success('Applied');setApplyM(false);load();}catch{}finally{setSaving(false);};
  };
  const doReview=async()=>{
    setSaving(true);try{await api.put(`/leaves/${reviewL._id}/review`,rev);toast.success(`${rev.status}`);setReviewL(null);load();}catch{}finally{setSaving(false);};
  };
  const cancel=async id=>{if(!window.confirm('Cancel?'))return;try{await api.delete(`/leaves/${id}`);toast.success('Cancelled');load();}catch{}};

  const SC={approved:{bg:'#f0fdf4',c:'#16a34a'},pending:{bg:'#fffbeb',c:'#d97706'},declined:{bg:'#fef2f2',c:'#dc2626'}};
  const SB=s=><span className="abadge" style={{background:SC[s]?.bg,color:SC[s]?.c}}>{s}</span>;

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:18,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>Leaves</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Approve, decline and track</p></div>
        <button className="abtn abtn-primary" onClick={()=>{setForm({employeeId:'',leaveType:'annual',startDate:'',endDate:'',reason:''});setApplyM(true);}}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/></svg> Apply
        </button>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:11,marginBottom:14}}>
        {[['Pending',stats.pending||0,'#d97706'],['Approved',stats.approved||0,'#16a34a'],['Declined',stats.declined||0,'#dc2626']].map(([l,v,c])=>(
          <div key={l} className="acard" style={{padding:14,cursor:'pointer'}} onClick={()=>setFilt(l.toLowerCase())}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--a-t3)',marginBottom:6}}>{l}</div>
            <div style={{fontSize:22,fontWeight:700,fontFamily:'var(--a-mono)',color:c}}>{v}</div>
          </div>
        ))}
      </div>

      <div className="acard" style={{padding:'8px 13px',marginBottom:12,display:'flex',gap:7}}>
        {['','pending','approved','declined'].map(s=>(
          <button key={s} className={`abtn abtn-sm ${filt===s?'abtn-primary':'abtn-outline'}`} onClick={()=>setFilt(s)}>{s||'All'}</button>
        ))}
      </div>

      <div className="acard" style={{overflow:'hidden'}}>
        <div className="tscroll">
          <table className="atable">
            <thead><tr><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Status</th><th>Reason</th><th style={{textAlign:'right'}}>Actions</th></tr></thead>
            <tbody>
              {busy?<tr><td colSpan={8}><div style={{padding:28,textAlign:'center',fontSize:11,color:'var(--a-t3)'}}>Loading…</div></td></tr>
              :!leaves.length?<tr><td colSpan={8}><div className="aempty">No leave records</div></td></tr>
              :leaves.map(lv=>(
                <tr key={lv._id}>
                  <td><div style={{fontWeight:500,color:'var(--a-text)',fontSize:12}}>{lv.employee?.firstName} {lv.employee?.lastName}</div><div style={{fontSize:10,color:'var(--a-t3)'}}>{lv.employee?.employeeCode}</div></td>
                  <td><span className="atag">{lv.leaveType}</span></td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11}}>{new Date(lv.startDate).toLocaleDateString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11}}>{new Date(lv.endDate).toLocaleDateString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontWeight:500}}>{lv.totalDays}d</td>
                  <td>{SB(lv.status)}</td>
                  <td style={{maxWidth:140,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',fontSize:11}}>{lv.reason}</td>
                  <td>
                    <div style={{display:'flex',justifyContent:'flex-end',gap:5}}>
                      {lv.status==='pending'&&<button className="abtn abtn-primary abtn-sm" onClick={()=>{setReviewL(lv);setRev({status:'approved',adminNote:''});}}>Review</button>}
                      {lv.status==='pending'&&<button className="abtn abtn-danger abtn-sm" onClick={()=>cancel(lv._id)}>✕</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Apply modal */}
      {applyM&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setApplyM(false)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>Apply Leave</div><button className="abtn-icon" onClick={()=>setApplyM(false)}>✕</button></div>
          <div className="amodal-b">
            <div><label className="alabel">Employee *</label><select className="ainput" value={form.employeeId} onChange={F(setForm,'employeeId')}><option value="">Select…</option>{emps.map(e=><option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}</select></div>
            <div><label className="alabel">Type</label><select className="ainput" value={form.leaveType} onChange={F(setForm,'leaveType')}>{'annual,sick,maternity,paternity,unpaid,other'.split(',').map(t=><option key={t} value={t}>{t}</option>)}</select></div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div><label className="alabel">Start *</label><input className="ainput" type="date" value={form.startDate} onChange={F(setForm,'startDate')}/></div>
              <div><label className="alabel">End *</label><input className="ainput" type="date" value={form.endDate} min={form.startDate} onChange={F(setForm,'endDate')}/></div>
            </div>
            <div><label className="alabel">Reason *</label><textarea className="ainput" rows={2} value={form.reason} onChange={F(setForm,'reason')} style={{resize:'vertical'}}/></div>
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setApplyM(false)}>Cancel</button><button className="abtn abtn-primary" onClick={apply} disabled={saving}>{saving?<Spinner/>:null}Submit</button></div>
        </div>
      </div>}

      {/* Review modal */}
      {reviewL&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setReviewL(null)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>Review Leave</div><button className="abtn-icon" onClick={()=>setReviewL(null)}>✕</button></div>
          <div className="amodal-b">
            <div style={{padding:11,background:'#f9fafb',borderRadius:6,fontSize:12}}>
              <div style={{fontWeight:500,color:'var(--a-text)'}}>{reviewL.employee?.firstName} {reviewL.employee?.lastName}</div>
              <div style={{fontFamily:'var(--a-mono)',fontSize:11,color:'var(--a-t2)',marginTop:2}}>{reviewL.leaveType} · {new Date(reviewL.startDate).toLocaleDateString('en-IN')} → {new Date(reviewL.endDate).toLocaleDateString('en-IN')} ({reviewL.totalDays}d)</div>
              <div style={{fontSize:11,color:'var(--a-t2)',marginTop:5}}>{reviewL.reason}</div>
            </div>
            <div><label className="alabel">Decision</label>
              <div style={{display:'flex',gap:7}}>
                {['approved','declined'].map(s=><button key={s} className={`abtn abtn-sm ${rev.status===s?(s==='approved'?'abtn-success':'abtn-danger'):'abtn-outline'}`} style={{flex:1,justifyContent:'center'}} onClick={()=>setRev(r=>({...r,status:s}))}>{s==='approved'?'✓ Approve':'✗ Decline'}</button>)}
              </div>
            </div>
            <div><label className="alabel">Note</label><textarea className="ainput" rows={2} value={rev.adminNote} onChange={e=>setRev(r=>({...r,adminNote:e.target.value}))} style={{resize:'vertical'}}/></div>
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setReviewL(null)}>Cancel</button><button className={`abtn ${rev.status==='approved'?'abtn-success':'abtn-danger'}`} onClick={doReview} disabled={saving}>{saving?<Spinner/>:null}Confirm</button></div>
        </div>
      </div>}
    </div>
  );
}

/* ════════════════════════════════════════
   ADMIN DEPARTMENTS
════════════════════════════════════════ */
export function AdminDepartments() {
  const [depts, setDepts]   = useState([]);
  const [busy,  setBusy]    = useState(true);
  const [modal, setModal]   = useState(null);
  const [sel,   setSel]     = useState(null);
  const [saving,setSaving]  = useState(false);
  const [detail,setDetail]  = useState(null);
  const [form,  setForm]    = useState({name:'',code:'',description:''});

  const load=async()=>{setBusy(true);try{const r=await api.get('/departments');setDepts(r.data.data.departments||[]);}catch{}finally{setBusy(false);};};
  useEffect(()=>{load();},[]);

  const save=async()=>{
    if(!form.name){toast.error('Name required');return;}
    setSaving(true);
    try{sel?await api.put(`/departments/${sel._id}`,form):await api.post('/departments',form);toast.success(sel?'Updated':'Created');setModal(null);load();}
    catch{}finally{setSaving(false);}
  };
  const del=async d=>{if(!window.confirm(`Delete ${d.name}?`))return;try{await api.delete(`/departments/${d._id}`);toast.success('Deleted');load();}catch{}};
  const viewDetail=async d=>{try{const r=await api.get(`/departments/${d._id}`);setDetail(r.data.data||{});}catch{toast.error('Failed');}};

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:22,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>Departments</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Company structure</p></div>
        <button className="abtn abtn-primary" onClick={()=>{setForm({name:'',code:'',description:''});setSel(null);setModal('form');}}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/></svg> New
        </button>
      </div>

      {busy?<div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12}}>{[1,2,3,4].map(i=><div key={i} className="acard" style={{height:110}}/>)}</div>:(
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12}}>
          {depts.map(d=>(
            <div key={d._id} className="acard" style={{padding:16,cursor:'pointer',transition:'border-color .14s'}}
              onMouseEnter={e=>e.currentTarget.style.borderColor='#d1d5db'}
              onMouseLeave={e=>e.currentTarget.style.borderColor='#e5e7eb'}
              onClick={()=>viewDetail(d)}>
              <div style={{display:'flex',justifyContent:'space-between',marginBottom:10}}>
                <div style={{width:32,height:32,borderRadius:7,background:'#f3f4f6',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14}}>🏢</div>
                <div style={{display:'flex',gap:5}} onClick={e=>e.stopPropagation()}>
                  <button className="abtn-icon" onClick={()=>{setForm({name:d.name,code:d.code||'',description:d.description||''});setSel(d);setModal('form');}}>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
                  </button>
                  <button className="abtn-icon" style={{color:'#dc2626',borderColor:'#fecaca'}} onClick={()=>del(d)}>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none"><polyline points="3 6 5 6 21 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/></svg>
                  </button>
                </div>
              </div>
              <div style={{fontWeight:600,color:'var(--a-text)',marginBottom:3,fontSize:14}}>{d.name}</div>
              {d.code&&<span className="atag" style={{marginBottom:5,display:'inline-block'}}>{d.code}</span>}
              {d.description&&<div style={{fontSize:11,color:'var(--a-t3)',marginBottom:6,lineHeight:1.5}}>{d.description}</div>}
              <div style={{fontSize:11,color:'var(--a-t2)',fontFamily:'var(--a-mono)'}}>{d.employeeCount||0} members</div>
            </div>
          ))}
          {!depts.length&&<div className="aempty" style={{gridColumn:'1/-1'}}>No departments yet</div>}
        </div>
      )}

      {modal==='form'&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>{sel?'Edit':'New'} Department</div><button className="abtn-icon" onClick={()=>setModal(null)}>✕</button></div>
          <div className="amodal-b">
            {[['Name *','name','Engineering'],['Code','code','ENG'],['Description','description','Brief…']].map(([l,k,p])=>(
              <div key={k}><label className="alabel">{l}</label><input className="ainput" value={form[k]} placeholder={p} onChange={e=>setForm(f=>({...f,[k]:e.target.value}))}/></div>
            ))}
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setModal(null)}>Cancel</button><button className="abtn abtn-primary" onClick={save} disabled={saving}>{saving?<Spinner/>:null}{sel?'Save':'Create'}</button></div>
        </div>
      </div>}

      {detail&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setDetail(null)}>
        <div className="amodal" style={{maxWidth:520}}>
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>{detail.department?.name} — Team ({detail.headcount})</div><button className="abtn-icon" onClick={()=>setDetail(null)}>✕</button></div>
          <div className="amodal-b">
            {!detail.employees?.length?<p style={{fontSize:13,color:'var(--a-t3)'}}>No active employees.</p>
            :detail.employees.map(e=>(
              <div key={e._id} style={{display:'flex',alignItems:'center',gap:9,padding:'8px 11px',background:'#f9fafb',borderRadius:6,border:'1px solid #f3f4f6'}}>
                <div style={{width:26,height:26,borderRadius:'50%',background:'#111827',display:'flex',alignItems:'center',justifyContent:'center',fontSize:10,fontWeight:700,color:'#fff'}}>{e.firstName?.charAt(0)}{e.lastName?.charAt(0)}</div>
                <div><div style={{fontSize:13,fontWeight:500,color:'var(--a-text)'}}>{e.firstName} {e.lastName}</div><div style={{fontSize:10,color:'var(--a-t3)',fontFamily:'var(--a-mono)'}}>{e.position} · {e.employeeCode}</div></div>
              </div>
            ))}
          </div>
        </div>
      </div>}
    </div>
  );
}

/* ════════════════════════════════════════
   ADMIN PAYROLL
════════════════════════════════════════ */
export function AdminPayroll() {
  const [records,setRecords]=useState([]);
  const [summary,setSummary]=useState({yearTotals:{grossSalary:0,netSalary:0,totalDeductions:0}});
  const [busy,   setBusy]  =useState(true);
  const [month,  setMonth] =useState(new Date().getMonth()+1);
  const [year,   setYear]  =useState(new Date().getFullYear());
  const [genBusy,setGenBusy]=useState(false);
  const [modal,  setModal] =useState(null);
  const [sel,    setSel]   =useState(null);
  const [saving, setSaving]=useState(false);
  const [bonus,  setBonus] =useState('');
  const [notes,  setNotes] =useState('');

  const load=useCallback(async()=>{
    setBusy(true);
    try{
      const[r,s]=await Promise.all([api.get('/payroll',{params:{month,year,limit:50}}),api.get('/payroll/summary',{params:{year}})]);
      setRecords(r.data.data || []);setSummary(s.data.data || {yearTotals:{grossSalary:0,netSalary:0,totalDeductions:0}});
    }catch{}finally{setBusy(false);}
  },[month,year]);
  useEffect(()=>{load();},[load]);

  const generate=async()=>{setGenBusy(true);try{const r=await api.post('/payroll/generate',{month,year});toast.success(`Generated ${r.data.data.generated} records`);load();}catch{}finally{setGenBusy(false);};};
  const markPaid=async id=>{try{await api.put(`/payroll/${id}/mark-paid`,{paymentMethod:'bank_transfer'});toast.success('Marked paid');load();}catch{}};
  const del=async id=>{if(!window.confirm('Delete draft?'))return;try{await api.delete(`/payroll/${id}`);toast.success('Deleted');load();}catch{}};
  const updateBonus=async()=>{setSaving(true);try{await api.put(`/payroll/${sel._id}`,{bonus:Number(bonus),notes});toast.success('Updated');setModal(null);load();}catch{}finally{setSaving(false);};};

  const M=['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const fmt=n=>n?`₹${(n/1000).toFixed(0)}K`:'₹0';

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:22,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>Payroll</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Generate and manage monthly payroll</p></div>
        <div style={{display:'flex',gap:7,alignItems:'center',flexWrap:'wrap'}}>
          <select className="ainput" style={{width:90}} value={month} onChange={e=>setMonth(Number(e.target.value))}>{M.slice(1).map((m,i)=><option key={i+1} value={i+1}>{m}</option>)}</select>
          <select className="ainput" style={{width:82}} value={year} onChange={e=>setYear(Number(e.target.value))}>{[2024,2025,2026].map(y=><option key={y} value={y}>{y}</option>)}</select>
          <button className="abtn abtn-primary" onClick={generate} disabled={genBusy}>{genBusy?<><Spinner/>Gen…</>:<>⚡ Generate</>}</button>
        </div>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(170px,1fr))',gap:12,marginBottom:18}}>
        {[['Gross',fmt(summary.yearTotals?.grossSalary),'var(--a-text)'],['Net',fmt(summary.yearTotals?.netSalary),'#16a34a'],['Deductions',fmt(summary.yearTotals?.totalDeductions),'#dc2626'],['Records',records.length,'#2563eb']].map(([l,v,c])=>(
          <div key={l} className="acard" style={{padding:16}}>
            <div style={{fontSize:10,fontWeight:600,textTransform:'uppercase',letterSpacing:'.07em',color:'var(--a-t3)',marginBottom:7}}>{l} {l!=='Records'?`(${year})`:''}</div>
            <div style={{fontSize:22,fontWeight:700,fontFamily:'var(--a-mono)',color:c}}>{v}</div>
          </div>
        ))}
      </div>

      <div className="acard" style={{overflow:'hidden'}}>
        <div className="tscroll">
          <table className="atable">
            <thead><tr><th>Employee</th><th>Basic</th><th>Gross</th><th>Deductions</th><th>Net</th><th>Days</th><th>Status</th><th style={{textAlign:'right'}}>Actions</th></tr></thead>
            <tbody>
              {busy?<tr><td colSpan={8}><div style={{padding:28,textAlign:'center',fontSize:11,color:'var(--a-t3)'}}>Loading…</div></td></tr>
              :!records.length?<tr><td colSpan={8}><div className="aempty">No payroll for {M[month]} {year}. Click Generate.</div></td></tr>
              :records.map(r=>(
                <tr key={r._id}>
                  <td><div style={{fontWeight:500,color:'var(--a-text)',fontSize:12}}>{r.employee?.firstName} {r.employee?.lastName}</div><div style={{fontSize:10,color:'var(--a-t3)'}}>{r.employee?.employeeCode}</div></td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11}}>₹{Number(r.basicSalary||0).toLocaleString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11,fontWeight:500}}>₹{Number(r.grossSalary||0).toLocaleString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11,color:'#dc2626'}}>-₹{Number(r.totalDeductions||0).toLocaleString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11,fontWeight:700,color:'#16a34a'}}>₹{Number(r.netSalary||0).toLocaleString('en-IN')}</td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11}}>{r.presentDays}/{r.workingDays}</td>
                  <td><span className={`abadge ${r.status==='paid'?'ab-green':r.status==='generated'?'ab-blue':'ab-gray'}`}>{r.status}</span></td>
                  <td>
                    <div style={{display:'flex',justifyContent:'flex-end',gap:5}}>
                      {r.status!=='paid'&&<button className="abtn abtn-outline abtn-sm" onClick={()=>{setSel(r);setBonus(r.bonus||'');setNotes(r.notes||'');setModal('bonus');}}>Edit</button>}
                      {r.status!=='paid'&&<button className="abtn abtn-success abtn-sm" onClick={()=>markPaid(r._id)}>Pay</button>}
                      {r.status!=='paid'&&<button className="abtn abtn-danger abtn-sm" onClick={()=>del(r._id)}>✕</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal==='bonus'&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setModal(null)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>Edit — {sel?.employee?.firstName}</div><button className="abtn-icon" onClick={()=>setModal(null)}>✕</button></div>
          <div className="amodal-b">
            <div><label className="alabel">Bonus (₹)</label><input className="ainput" type="number" value={bonus} onChange={e=>setBonus(e.target.value)} placeholder="0"/></div>
            <div><label className="alabel">Notes</label><textarea className="ainput" rows={2} value={notes} onChange={e=>setNotes(e.target.value)} style={{resize:'vertical'}}/></div>
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setModal(null)}>Cancel</button><button className="abtn abtn-primary" onClick={updateBonus} disabled={saving}>{saving?<Spinner/>:null}Save</button></div>
        </div>
      </div>}
    </div>
  );
}

/* ════════════════════════════════════════
   ADMIN KIN
════════════════════════════════════════ */
export function AdminKin() {
  const [kins,   setKins]  =useState([]);
  const [missing,setMiss]  =useState([]);
  const [emps,   setEmps]  =useState([]);
  const [busy,   setBusy]  =useState(true);
  const [modal,  setModal] =useState(false);
  const [saving, setSaving]=useState(false);
  const [form,   setForm]  =useState({employeeId:'',name:'',relationship:'spouse',phone:'',email:'',address:''});

  const load = useCallback(async () => {
  setBusy(true);
  try {
    const r = await api.get('/kin');
    setKins(r.data.data.kins || []);
    setMiss(r.data.data.missingKin || []);
  } catch (err) {
    console.error(err);
  } finally {
    setBusy(false);
  }
}, []);
  useEffect(()=>{load();api.get('/employees',{params:{limit:100}}).then(r=>setEmps(r.data.data||[])).catch(()=>{});},[load]);

  const save=async()=>{
    if(!form.employeeId||!form.name||!form.phone){toast.error('Fill required fields');return;}
    setSaving(true);try{await api.post('/kin',form);toast.success('Saved');setModal(false);load();}catch{}finally{setSaving(false);}
  };
  const del=async id=>{if(!window.confirm('Delete?'))return;try{await api.delete(`/kin/${id}`);toast.success('Deleted');load();}catch{}};

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:18,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>Emergency Contacts</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Next of kin for all employees</p></div>
        <button className="abtn abtn-primary" onClick={()=>{setForm({employeeId:'',name:'',relationship:'spouse',phone:'',email:'',address:''});setModal(true);}}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/></svg> Add
        </button>
      </div>

      {missing.length>0&&<div style={{padding:'11px 14px',background:'#fef2f2',border:'1px solid #fecaca',borderRadius:7,marginBottom:14,display:'flex',gap:10,alignItems:'center'}}>
        <span>⚠️</span><div><div style={{fontSize:12,fontWeight:600,color:'#dc2626'}}>{missing.length} employee(s) missing emergency contact</div><div style={{fontSize:11,color:'#6b7280',marginTop:1}}>{missing.map(e=>`${e.firstName} ${e.lastName}`).join(', ')}</div></div>
      </div>}

      <div className="acard" style={{overflow:'hidden'}}>
        <div className="tscroll">
          <table className="atable">
            <thead><tr><th>Employee</th><th>Contact</th><th>Relationship</th><th>Phone</th><th>Email</th><th style={{textAlign:'right'}}>Actions</th></tr></thead>
            <tbody>
              {busy?<tr><td colSpan={6}><div style={{padding:28,textAlign:'center',fontSize:11,color:'var(--a-t3)'}}>Loading…</div></td></tr>
              :!kins.length?<tr><td colSpan={6}><div className="aempty">No emergency contacts</div></td></tr>
              :kins.map(k=>(
                <tr key={k._id}>
                  <td><div style={{fontWeight:500,color:'var(--a-text)',fontSize:12}}>{k.employee?.firstName} {k.employee?.lastName}</div><div style={{fontSize:10,color:'var(--a-t3)'}}>{k.employee?.employeeCode}</div></td>
                  <td style={{fontWeight:500,color:'var(--a-text)'}}>{k.name}</td>
                  <td><span className="atag">{k.relationship}</span></td>
                  <td style={{fontFamily:'var(--a-mono)',fontSize:11}}>{k.phone}</td>
                  <td style={{fontSize:12}}>{k.email||'—'}</td>
                  <td><div style={{display:'flex',justifyContent:'flex-end'}}><button className="abtn abtn-danger abtn-sm" onClick={()=>del(k._id)}>Remove</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>Add Emergency Contact</div><button className="abtn-icon" onClick={()=>setModal(false)}>✕</button></div>
          <div className="amodal-b">
            <div><label className="alabel">Employee *</label><select className="ainput" value={form.employeeId} onChange={F(setForm,'employeeId')}><option value="">Select…</option>{emps.map(e=><option key={e._id} value={e._id}>{e.firstName} {e.lastName} ({e.employeeCode})</option>)}</select></div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div><label className="alabel">Name *</label><input className="ainput" value={form.name} placeholder="Jane Doe" onChange={F(setForm,'name')}/></div>
              <div><label className="alabel">Relationship</label><select className="ainput" value={form.relationship} onChange={F(setForm,'relationship')}>{'spouse,parent,sibling,child,friend,other'.split(',').map(r=><option key={r} value={r}>{r}</option>)}</select></div>
              <div><label className="alabel">Phone *</label><input className="ainput" value={form.phone} placeholder="+91…" onChange={F(setForm,'phone')}/></div>
              <div><label className="alabel">Email</label><input className="ainput" type="email" value={form.email} placeholder="jane@…" onChange={F(setForm,'email')}/></div>
            </div>
            <div><label className="alabel">Address</label><input className="ainput" value={form.address} placeholder="Street, City" onChange={F(setForm,'address')}/></div>
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setModal(false)}>Cancel</button><button className="abtn abtn-primary" onClick={save} disabled={saving}>{saving?<Spinner/>:null}Save</button></div>
        </div>
      </div>}
    </div>
  );
}

/* ════════════════════════════════════════
   ADMIN USERS
════════════════════════════════════════ */
export function AdminUsers() {
  const [users, setUsers] =useState([]);
  const [emps,  setEmps]  =useState([]);
  const [busy,  setBusy]  =useState(true);
  const [modal, setModal] =useState(false);
  const [saving,setSaving]=useState(false);
  const [form,  setForm]  =useState({name:'',email:'',password:'',role:'employee',employeeId:''});

  const load=async()=>{setBusy(true);try{const r=await api.get('/auth/users');setUsers(r.data.data.users||[]);}catch{}finally{setBusy(false);};};
  useEffect(()=>{load();api.get('/employees',{params:{limit:100}}).then(r=>setEmps(r.data.data||[])).catch(()=>{});},[]);

  const create=async()=>{
    if(!form.name||!form.email||!form.password){toast.error('Name, email, password required');return;}
    setSaving(true);try{await api.post('/auth/register',form);toast.success('Created');setModal(false);load();}catch{}finally{setSaving(false);}
  };
  const toggle=async id=>{try{const r=await api.put(`/auth/users/${id}/toggle`);toast.success(r.data.message);load();}catch{}};
  const link=async(uid,eid)=>{if(!eid)return;try{await api.put('/auth/link-employee',{userId:uid,employeeId:eid});toast.success('Linked');load();}catch{}};

  return(
    <div className="page">
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:22,flexWrap:'wrap',gap:12}}>
        <div><h1 style={{fontSize:20,fontWeight:700,color:'var(--a-text)'}}>User Accounts</h1><p style={{fontSize:12,color:'var(--a-t3)'}}>Manage portal access</p></div>
        <button className="abtn abtn-primary" onClick={()=>{setForm({name:'',email:'',password:'',role:'employee',employeeId:''});setModal(true);}}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"/></svg> Create User
        </button>
      </div>

      <div className="acard" style={{overflow:'hidden'}}>
        <div className="tscroll">
          <table className="atable">
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Linked Employee</th><th>Status</th><th>Last Login</th><th style={{textAlign:'right'}}>Actions</th></tr></thead>
            <tbody>
              {busy?<tr><td colSpan={7}><div style={{padding:28,textAlign:'center',fontSize:11,color:'var(--a-t3)'}}>Loading…</div></td></tr>
              :users.map(u=>(
                <tr key={u._id}>
                  <td><div style={{display:'flex',alignItems:'center',gap:7}}><div style={{width:24,height:24,borderRadius:'50%',background:'#111827',display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,fontWeight:700,color:'#fff'}}>{u.name?.charAt(0)}</div><span style={{fontWeight:500,color:'var(--a-text)',fontSize:12}}>{u.name}</span></div></td>
                  <td style={{fontSize:11,fontFamily:'var(--a-mono)'}}>{u.email}</td>
                  <td><span className={`abadge ${u.role==='admin'?'ab-blue':'ab-gray'}`}>{u.role}</span></td>
                  <td>
                    {u.employeeId
                      ?<span style={{fontSize:11,fontFamily:'var(--a-mono)',color:'#16a34a'}}>{u.employeeId?.firstName} {u.employeeId?.lastName}</span>
                      :u.role==='employee'
                        ?<select style={{fontSize:10,padding:'2px 5px',border:'1px solid #e5e7eb',borderRadius:4,background:'#fff',fontFamily:'var(--a-mono)',color:'var(--a-t2)'}} onChange={e=>link(u._id,e.target.value)}>
                          <option value="">Link…</option>
                          {emps.filter(e=>e.status==='active').map(e=><option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}
                        </select>
                        :<span style={{color:'var(--a-t3)',fontSize:11}}>—</span>
                    }
                  </td>
                  <td><span className={`abadge ${u.isActive?'ab-green':'ab-red'}`}>{u.isActive?'Active':'Inactive'}</span></td>
                  <td style={{fontSize:10,fontFamily:'var(--a-mono)',color:'var(--a-t3)'}}>{u.lastLogin?new Date(u.lastLogin).toLocaleDateString('en-IN'):'Never'}</td>
                  <td><div style={{display:'flex',justifyContent:'flex-end'}}><button className={`abtn abtn-sm ${u.isActive?'abtn-danger':'abtn-success'}`} onClick={()=>toggle(u._id)}>{u.isActive?'Deactivate':'Activate'}</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {modal&&<div className="aoverlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}>
        <div className="amodal">
          <div className="amodal-h"><div style={{fontWeight:600,fontSize:15}}>Create User Account</div><button className="abtn-icon" onClick={()=>setModal(false)}>✕</button></div>
          <div className="amodal-b">
            <div><label className="alabel">Full Name *</label><input className="ainput" value={form.name} onChange={F(setForm,'name')} placeholder="John Doe"/></div>
            <div><label className="alabel">Email *</label><input className="ainput" type="email" value={form.email} onChange={F(setForm,'email')} placeholder="john@co.com"/></div>
            <div><label className="alabel">Password * (min 8, upper+lower+number)</label><input className="ainput" type="password" value={form.password} onChange={F(setForm,'password')} placeholder="Secure@1234"/></div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
              <div><label className="alabel">Role</label><select className="ainput" value={form.role} onChange={F(setForm,'role')}><option value="employee">Employee</option><option value="admin">Admin</option></select></div>
              <div><label className="alabel">Link Employee</label><select className="ainput" value={form.employeeId} onChange={F(setForm,'employeeId')}><option value="">None</option>{emps.map(e=><option key={e._id} value={e._id}>{e.firstName} {e.lastName}</option>)}</select></div>
            </div>
          </div>
          <div className="amodal-f"><button className="abtn abtn-outline" onClick={()=>setModal(false)}>Cancel</button><button className="abtn abtn-primary" onClick={create} disabled={saving}>{saving?<Spinner/>:null}Create</button></div>
        </div>
      </div>}
    </div>
  );
}
